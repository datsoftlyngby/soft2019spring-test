package testex;

public class JokeException extends Exception {
  public JokeException(String message) {
    super(message);
  }
}
