# startCodeForTesting1
This project contains start code for an exercise given at cphbusiness.dk for the educations:
* AP degree in Computer Science
* Top-up Bachelor's degree in Software Developement
